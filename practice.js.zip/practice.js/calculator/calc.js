
/*let screen = document.getElementById("screen");
    buttons = document.querySelectorAll('button')
    for(item of buttons){
        item.addEventListner('click',(e)=>{
            buttonText = e.target.innerHTML;
            console.log("button text is" , buttonText);
            

        });
    };*/
    /*function getRandomColor() {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
          color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
      }
      
      
      
      
      function setRandomColor() {
        $("#colorpad").css("background-color", getRandomColor());
        console.log(body)
      }
      */
      var name="";
      var message="";
     function f1(){
    var age  = document.getElementById("compare").value;
    const yourname = document.getElementById("userName").value;
     console.log(age);
      
      
     if (age < 6){
       message= age + " is less than given age";
       console.log(message)
     }
      else if ( age > 6){
      message= age + "is greater than given number" ;
      console.log(message)
     }
     else {
       message=" you made it:" + yourname;
       console.log(message)
     }
    
    }
    document.getElementById("screen").innerHTML=message;