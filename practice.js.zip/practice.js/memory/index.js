let a;
let date;
let time;
const options = { weekday:'long', year: 'numeric', month: 'long',day: 'numeric'};
setInterval(() => {
    a = new Date();
    date = a.toLocaleDateString(undefined,options);
    time = a.getHours() + ':' + a.getMinutes() + ':' + a.getSeconds();
    document.getElementById("top").innerHTML= time + "<br>on" + date;
    
}, 1000);

//form

function getandupdate(){
    console.log("hello");
    lis = document.getElementById("list").value;
    sub= document.getElementById("subject").value;
    
       if(localStorage.getItem("itemsJson")==null){
           itemJsonArray = [];
           itemJsonArray.push([lis, sub]);
           localStorage.setItem("itemsJson",JSON.stringify(itemJsonArray))
       } 
       else
       {
           itemJsonArraystr = localStorage.getItem("itemsJson")
           itemJsonArray = JSON.parse(itemJsonArraystr);
           itemJsonArray.push([lis, sub]);
           localStorage.setItem("itemsJson", JSON.stringify(itemJsonArray))
    
       }
       update();
       
    }
       function update(){
           
           if(localStorage.getItem("itemsJson")==null){
        itemJsonArray = [];
         localStorage.setItem("itemsJson",JSON.stringify(itemJsonArray))
    } 
    else
       {
           itemJsonArraystr = localStorage.getItem("itemsJson")
             itemJsonArray = JSON.parse(itemJsonArraystr);
           
       }
       //populate
    let tablebody=document.getElementById("tablebody");
    let str = "";
    itemJsonArray.forEach((element,index) => {
     str += `
     
            <tr>
                <td> ${index + 1}</td>
                <td>${element[0]}</td>
                <td>${element[1]}</td>
                <td><button onclick ="deleted(${index})">Delete</button></td>
              </tr>
             `;
    });
     tablebody.innerHTML=str;
     
 
}
submit = document.getElementById("submit");
submit.addEventListener("click",getandupdate);
update();
function deleted(itemIndex){
    console.log("delete",itemIndex);
    itemJsonArraystr = localStorage.getItem("itemsJson")
    itemJsonArray = JSON.parse(itemJsonArraystr);
 
//delecte itemundex
itemJsonArray.splice(itemIndex,1);
localStorage.setItem("itemsJson",JSON.stringify(itemJsonArray))
update();
}
//clear
function clearstor(){
    if(confirm("Do You Really Want To Clear All Memories??????")){

    
    localStorage.clear();
    
    update();
    }
}
//dark mood
function reset() {
      
	var elements = document.getElementsByClassName('grid-container'); // get all elements
    console.log("clicked")
	for(var i = 0; i < elements.length; i++){
		elements[i].style.backgroundColor = "#FAEBD7";
	}
}